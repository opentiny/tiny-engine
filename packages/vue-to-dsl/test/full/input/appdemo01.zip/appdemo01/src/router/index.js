import { createRouter, createWebHashHistory } from 'vue-router'
const routes = [
  {
    path: '/',
    redirect: {
      name: '1'
    },
    children: [
      {
        name: '5bhD7p5FUsUOTFRN',
        path: 'demopage',
        component: () => import('@/views/DemoPage.vue'),
        children: []
      },
      {
        name: '1',
        path: 'createVm',
        component: () => import('@/views/createVm.vue'),
        children: [
          {
            name: '3sV9KkvL3SuQIufS',
            path: 'untitledFA/UntitledA',
            component: () => import('@/views/createVm/untitledFA/UntitledA.vue'),
            children: []
          }
        ],
        redirect: {
          name: '3sV9KkvL3SuQIufS'
        }
      },
      {
        name: 'lifecycle-page',
        path: 'lifecycle',
        component: () => import('@/views/LifeCyclePage.vue'),
        children: []
      },
      {
        name: '1737797330916',
        path: 'testCanvasRowCol',
        component: () => import('@/views/testCanvasRowCol.vue'),
        children: []
      }
    ]
  }
]

export default createRouter({
  history: createWebHashHistory(),
  routes
})
